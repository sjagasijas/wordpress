
<!DOCTYPE html>
<html <?php language_attributes(); ?> >


  <head>

    <meta charset="<?php bloginfo('charset'); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="<?php bloginfo('description'); ?>">
    
    

    <title><?php the_title(); ?></title>

    <!-- Bootstrap core CSS -->
    <link href="<?php bloginfo('template_url');?>/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="<?php bloginfo('stylesheet_url');?>" rel="stylesheet">
    

    <link href="<?php bloginfo('template_url');?>/css/swiper.min.css" rel="stylesheet">


    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet">


    <!--<link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Open+Sans" /> -->


    <?php wp_head();?>

   
  </head>






<style>

.nav > li > a {

    position: relative;
    display: block;
    padding: unset;
        margin-right: 10px;
}



.nav>li>a:focus, .nav>li>a:hover {
    border-radius: 10px;
}




 .blog-nav a {
   color:#352e2e;
   height: 55px;
   line-height: 50px !important;
   text-align: center;
 }


.blog-nav .dropdown-menu a:hover {
    color: #2d2d2d;
    text-decoration: unset;
    background:#eee;
    /* text-decoration: underline; */
}



.blog-nav .dropdown-menu a {

display:flex;
padding-left: 10px;

}










@media only screen and (min-width: 1200px) {
    .menu-item {
    width: 140px !important;
}


</style>








  <body>




<div class="main-container">  


  <div class="blog-masthead">

      <div class="container">

        <nav class="blog-nav">

        <?php

          $custom_logo_id = get_theme_mod( 'custom_logo' );
$logo = wp_get_attachment_image_src( $custom_logo_id , 'full' );
if ( has_custom_logo() ) {
        echo '

        <div class="header-logo">

        <a href=" '.home_url('/').'explainer-videos"> <img src="'. esc_url( $logo[0] ) .'"> </a>

        </div> ';
} 




else   {

        echo '<h1>'. get_bloginfo('name') .'</h1>';

}



        wp_nav_menu(array(

                'menu'              => 'explainer-video-menu',
                'theme_location'    => 'explainer-video-menu',
                'depth'             => 2,
                'container'         => 'div',
                'container_class'   => 'collapse navbar-collapse',
                'container_id'      => 'bs-example-navbar-collapse-1',
                'menu_class'        => 'nav navbar-nav',
                'fallback_cb'       => 'wp_bootstrap_navwalker::fallback',
                'walker'            => new wp_bootstrap_navwalker())

            );?>
        
        </nav>

      </div>

      </div>