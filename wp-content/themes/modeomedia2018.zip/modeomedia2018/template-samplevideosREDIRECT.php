<?php


/*
Template Name: Sample Videos(REDIRECT)
*/


header("Location:https://modeomedia.com/marketing-videos/videos/healthcare");


?>